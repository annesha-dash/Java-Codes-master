
class Main{
	public static void main(String [] aa ){
		//Registration l = new Registration();
		MyLoginWindow ml=new MyLoginWindow();
		ml.setVisible(true);
		ml.setSize(400,400);
		ml.setTitle("my login window");

	}
}