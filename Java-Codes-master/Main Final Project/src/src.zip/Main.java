package main;
import main.login.*;

public class Main  {
    
	public static void main(String[] args){

		new Login();
		
		}

}