class Child extends Parent{
	
	
	@Override
	public void method(){
		
		System.out.println("Childs method");
	}
	//super method();  //can't call the parent class copy from the class perenthisis but can be accessed from another method.
	
	public void m(){
		
		
		super.method();
	}
}