class Parent{
	
	
	
	public void method(){
		
		System.out.println("Parent's method");
	}
}