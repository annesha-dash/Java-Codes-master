<!DOCTYPE html>
<html lang="en">
<?php 
    include_once('lib.php');
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Messages</title>
    <link rel="stylesheet" href="css/msg.css?version=5">
    <link href="css/font-awesome.css?version=4.7.0" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
</head>

<body>
    <div class="container">
        <div class="navbar">
            <a href="#">
                <img src="img/logo.png" alt="logo">
            </a>
            <div class="search_bar">
                <input type="text" value="search..">
                <button type="button" id="search">
                    <i class="fa fa-search" aria-hidden="true"></i>
                </button>
            </div>
            <h1>
                <a href="#">
                    <i class="fa fa-user" aria-hidden="true"></i>
                </a>
            </h1>
            <h1>
                <a href="#">
                    <i class="fa fa-bell" aria-hidden="true"></i>
                </a>
            </h1>
            <h1>
                <a href="#">
                    <i class="fa fa-inbox" aria-hidden="true"></i>
                </a>
            </h1>
        </div>
        <div class="wrapper">
            <div class="side-bar">
                <div class="top-bar">
                    COMPOSE
                    <i class="fa fa-envelope-o" aria-hidden="true" style="margin-left:18%;color:rgb(0, 163, 0)"></i>
                </div>
                <div class="bottom-bar">
                    <button style="margin-top:80px" onclick="showMsgList()">
                        <div style="float:left">Inbox</div>
                        <div class=badge>1</div>
                    </button>
                    <button onclick="showMsgList()">
                        <div style="float:left">Sent</div>
                        <div class=badge>1</div>
                    </button>
                    <button onclick="showMsgList()">
                        <div style="float:left">Draft</div>
                        <div class=badge>1</div>
                    </button>
                </div>
            </div>
            <div class="msg-list     ">
                <div class="top-bar2">
                    <select>
                        <option value="0">Bulk Actions</option>
                        <option value="1">Mark Read</option>
                        <option value="2">Mark Un-read</option>
                        <option value="3">Delete</option>
                    </select>
                    <button>Apply</button>
                    <div class="search_bar" style="float:right;margin-right:20px;padding:3px;border:1px solid rgb(66, 66, 66)">
                        <input type="text" value="search..">
                        <button type="button" id="search2">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>

                <table>
                    <tr>
                        <th class="check">
                            <input type="checkbox">
                        </th>
                        <th class="from">FROM</th>
                        <th class="subject">SUBJECT</th>
                        <th class="date">DATE</th>
                        <th class="action">ACTIONS</th>
                    </tr>
                    <?php 
                    $query = 'select * from message where u_id = "'.$_SESSION['p_id'].'" or f_u_id ="'.$_SESSION['p_id'].'" order by time DESC';
                    $res = q($query);
                    while ($x = mysqli_fetch_assoc($res)) { 

                        if($x['u_id'] == $_SESSION['p_id'] ){
                            $query1 = 'select * from profile where id = "'.$x['f_u_id'].'"';
                            $profile = mysqli_fetch_assoc($query1);                              
                            echo '<tr>
                            <td>
                                <input type="checkbox">
                            </td>
                            <td>
                                <img src="'.$profile['d_p_loc'].'" class="dp" alt=""> '.$profile['name'].'</td>
                            <td style="text-align:left">
                                <a class="subject-re" href="#"  data-msg-list = "1" id="1" onclick="showMsg(this)">Re:This is heading for the mail</a>
                                    '$x['msg']'
                                </td>
                            <td>Jan 8</td>
                            <td class="action">
                                <a href="#">Read</a>
                                <div style="height:10px"></div>
                                <a href="#">Delete</a>
                            </td>
                        </tr>';
                        }
                        else{


                        }             
                    }
                    ?>

                </table>

            </div>

            <div class="msg-show disable">
                <h1>Re:This is heading for the mail</h1>
                <h2>Conversation between
                    <a href="">jill</a> and You.
                    <input type="button" id="delete" value="Delete">
                </h2>
                <div class="msg-box">
                    <div class="msg-body">
                        <div class="left-side">
                            <img src="img/profile.jpg" alt="">
                        </div>
                        <div class="right-side">
                            <h1>
                                <a href="">Jill</a>
                                <div>Sent 10 months ago</div>
                            </h1>
                            <h2>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Facere, placeat sint distinctio obcaecati
                                tempora quasi veritatis vel eos consequatur cumque minima temporibus repudiandae ut natus
                                mollitia sit ducimus quam laborum. Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                Doloribus, velit facere? Asperiores deleniti dicta corrupti debitis totam fuga iste esse
                                error magni corporis porro nostrum, consequuntur saepe enim fugit hic! Lorem ipsum dolor
                                sit, amet consectetur adipisicing elit. Corrupti ad soluta veniam necessitatibus officiis
                                impedit vitae incidunt consectetur sunt quasi! Omnis aspernatur, accusantium nostrum voluptate
                                impedit alias fugit fuga suscipit.</h2>
                        </div>
                    </div>
                    <div class="msg-body">
                        <div class="left-side">
                            <img src="img/profile.jpg" alt="">
                        </div>
                        <div class="right-side">
                            <h1>
                                <a href="">Jill</a>
                                <div>Sent 10 months ago</div>
                            </h1>
                            <h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non quidem ratione sit quisquam voluptatibus
                                ullam soluta totam dolores perspiciatis itaque. Impedit soluta repudiandae reiciendis placeat
                                quisquam quibusdam sed eius. Maxime. Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                Amet culpa exercitationem labore tempore explicabo vel non corrupti ullam aliquam. Fugit
                                vitae et obcaecati cumque ratione laudantium ducimus, voluptatibus porro odio.</h2>
                        </div>
                    </div>
                    <div class="msg-body">
                        <div class="left-side">
                            <img src="img/profile.jpg" alt="">
                        </div>
                        <div class="right-side">
                            <h1>
                                <a href="">Jill</a>
                                <div>Sent 10 months ago</div>
                            </h1>
                            <h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non quidem ratione sit quisquam voluptatibus
                                ullam soluta totam dolores perspiciatis itaque. Impedit soluta repudiandae reiciendis placeat
                                quisquam quibusdam sed eius. Maxime. Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                Amet culpa exercitationem labore tempore explicabo vel non corrupti ullam aliquam. Fugit
                                vitae et obcaecati cumque ratione laudantium ducimus, voluptatibus porro odio.</h2>
                        </div>
                    </div>
                    <div class="msg-body">
                        <div class="left-side">
                            <img src="img/profile.jpg" alt="">
                        </div>
                        <div class="right-side">
                            <h1>
                                Send a reply
                            </h1>
                            <br>
                            <textarea></textarea>
                            <button>submit</button>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    </div>
    <script src="js/msg.js?version=8"></script>
</body>

</html>