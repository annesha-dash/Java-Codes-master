
var updateHeight = function() {
    var x = document.getElementsByClassName("msg-body");
    
    for(i = 0 ; i < x.length ; i++){
    
       var height =  x[i].children[1].offsetHeight;
        x[i].style.height= ""+(height+20)+"px";
    }
}

//document.getElementsByClassName("msg-list")[0].classList.remove("disable");
//document.getElementsByClassName("msg-show")[0].classList.add("disable");
var x = document.getElementsByClassName("navbar")[0].offsetHeight;

document.getElementsByClassName("search_bar")[0].style.marginTop = ""+(x*0.1)+"px";

function showMsgList(){

    document.getElementsByClassName("msg-list")[0].classList.remove("disable");
    document.getElementsByClassName("msg-show")[0].classList.add("disable");


}

function showMsg(e){
    
   var userId =  e.getAttribute("data-msg-list");
   document.getElementsByClassName("msg-list")[0].classList.add("disable");
   document.getElementsByClassName("msg-show")[0].classList.remove("disable");
   
   updateHeight();

   
}