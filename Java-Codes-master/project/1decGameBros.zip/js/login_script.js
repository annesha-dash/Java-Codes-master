var x = document.getElementById("login_input_form");
var y = document.getElementById("sign_up_form");

function showLogin() {
    y.classList.add("hidden");
    x.classList.remove("hidden");

}

function showReg() {
    x.classList.add("hidden");
    y.classList.remove("hidden");

}

function validateLogin(email, password) {
    var flag = 0;

        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (password.length == 0 || email.length == 0) {
            //alert('1');
            flag = 1;
            document.getElementById("error-msg").innerHTML = 'Must Fill up all fields';
            document.getElementById('l_pass').focus();
            return false;
        }
        else if (!filter.test(email)) {
            flag = 1;
            //alert('2');
            document.getElementById("error-msg").innerHTML = 'Invalid Email or, Nick';
            document.getElementById('l_email').focus();
            return false;
        }
        else if (email.charAt(0) !== '#' && flag != 0) {
            flag = 1;
            //alert('3');
            document.getElementById("error-msg").innerHTML = 'Invalid Email or, Nick';
            document.getElementById('l_email').focus();
            return false;

        }
        
    if (flag == 0) {
        return true;
    }


}
var eflag = 0;
var nflag = 0;
var pflag = 0;
var rpflag = 0;

function validateReg() {
   // alert(eflag);
   // alert(nflag);
  //  alert(pflag);
   // alert(rpflag);
    if (eflag == 0 || nflag == 0 || pflag == 0 || rpflag == 0) {

        document.getElementById("error-msg1").innerHTML = "Must fullfill all requirements"
        return true;
    }
    else false;

}






function checkExist(e) {

    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var type = e.getAttribute("data-input-type");
    if (type == 1) {
        var icon = e.nextElementSibling;
        icon.classList.remove("disable");
        if (filter.test(e.value)) {
            //  alert("hey");
            eflag =1;
            icon.classList.remove("fa-exclamation-circle");
            icon.classList.add("fa-check-circle");
            icon.style.color = "green";
        }
        else{
            eflag = 0;
            icon.classList.add("fa-exclamation-circle");
            icon.classList.remove("fa-check-circle");
            icon.style.color = "red";

        }
    }
    else if (type == 2) {
        var icon = e.nextElementSibling;
        icon.classList.remove("disable");
        if (e.value.charAt(0) == '#' && e.value.split('#').length - 1 == 1 && e.value.length > 2) {
            nflag = 1;
            icon.classList.remove("fa-exclamation-circle");
            icon.classList.add("fa-check-circle");
            icon.style.color = "green";

        }
        else{
            nflag = 0;
            icon.classList.add("fa-exclamation-circle");
            icon.classList.remove("fa-check-circle");
            icon.style.color = "red";

        }
    }
    else if (type == 3) {
        var icon = e.nextElementSibling;
        icon.classList.remove("disable");
        if (e.value.length >= 8) {
            pflag = 1;
            icon.classList.remove("fa-exclamation-circle");
            icon.classList.add("fa-check-circle");
            icon.style.color = "green";

        }
        else{
            pflag = 0;
            icon.classList.add("fa-exclamation-circle");
            icon.classList.remove("fa-check-circle");
            icon.style.color = "red";

        }
    }

    else if (type == 4) {
        var icon = e.nextElementSibling;
        icon.classList.remove("disable");
        var pass = document.getElementById("s_pass").value;
        if (e.value === pass) {
            rpflag =1;
            icon.classList.remove("fa-exclamation-circle");
            icon.classList.add("fa-check-circle");
            icon.style.color = "green";

        }
        else{
            rpflag = 0;
            icon.classList.add("fa-exclamation-circle");
            icon.classList.remove("fa-check-circle");
            icon.style.color = "red";

        }

    }



}

function request(url, vars) {

    var ajax = new XMLHttpRequest();
    ajax.open("POST", url, true);
    ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            var return_data = ajax.responseText;
            //alert(return_data.trim() == "0");
           // alert(return_data);
            if (return_data.trim() == '1') {
                document.getElementById("error-msg").innerHTML = 'Invalid Username or Password';
            }
            else if (return_data.trim() == "0") {
               // alert(return_data);
                alert("Login Successfull");
                window.location = "index.php";

            }
            else if( return_data.trim() == "2" ){
                document.getElementById("error-msg1").innerHTML = 'Invalid E-mail';

            }
            else if( return_data.trim() == "3" ){
                document.getElementById("error-msg1").innerHTML = 'Passwords do not match';
            }
            else if( return_data.trim() == "4" ){
                document.getElementById("error-msg1").innerHTML = 'Invalid Nickname';
                
            }
            
            else if( return_data.trim() == "5" ){
                alert("Registered successfully");
                document.getElementById('l_email').value = document.getElementById('s_email').value;
                showLogin();
            }

        }
    }
    ajax.send(vars);
}




document.getElementById("signUp").addEventListener("click", function () {
    showReg();
});

document.getElementById("login").addEventListener("click", function () {
    showLogin()
});

document.getElementById("l_confirm").addEventListener("click", function () {

    var email = document.getElementById("l_email").value;
    var pass = document.getElementById("l_pass").value;
    var vars = "l_email=" + email + "&l_password=" + pass;
   // alert("hey");
    var url = "check_cred.php";
    var res = validateLogin(email, pass);
   // alert("hey");
    if (res) var data = request(url, vars);


});


document.getElementById("s_confirm").addEventListener("click", function () {

    var email = document.getElementById("s_email").value;
    var nick = document.getElementById("s_nick").value;
    var pass = document.getElementById("s_pass").value;
    var rpass = document.getElementById("s_rpass").value;
    var url = "check_cred.php";
    var vars = "s_email=" + email + "&s_nick=" + nick + "&s_pass=" + pass + "&s_rpass=" + rpass;
    var data = request(url, vars);
});
