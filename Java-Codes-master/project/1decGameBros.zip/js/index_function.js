function loadAll() {
    loadFeed('1');
    addExpand();
}

function loadFriend() {
    loadFeed('2');
    addExpand();
}

function loadFollower() {
    loadFeed('3');
    addExpand();
}

function loadFollower() {
    loadFeed('4');
    addExpand();
}


function loadFeed($type) {

    $.post('feed.php', {
        type: $type
    }, function (data) {
        document.getElementsByClassName('feed_element')[0].innerHTML = data;
        addExpand();
    });

}

function addExpand() {
    $('.expand').each(function () {
        this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;');
    }).on('input', function () {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });
}
loadAll();
function addExpand_status() {
    $('#expand-status').each(function () {
        this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;');
    }).on('input', function () {
        this.style.height = 'auto';
        var parent = $('.status')[0];
        this.style.height = (this.scrollHeight + 100) + 'px';
        var feed = $('.feed_element');
        feed[0].style.top = (this.scrollHeight + 100) + 'px';
        parent.style.height = (this.scrollHeight + 50) + 'px'
        var z = $('#expand-status');
        var height = z[0].offsetHeight;
        var y = $('#status-button')[0];
        y.style.top = "" + (height + 30) + "px"


    });
}

function sharePost(){
    var file_data = $('#post-picture').prop('files')[0];
    var form_data = new FormData();
    $post = $('#expand-status').val();
    form_data.append('file', file_data);
   // alert(form_data);
   $.post("post.php" , {post : $post} ,function (data) {
       //document.getElementsByClassName('feed_element')[0].innerHTML = data;  
   })
    $.ajax({
        url: 'post.php', // point to server-side PHP script 
        dataType: 'text',  // what to expect back from the PHP script, if anything
        cache: false,
        contentType: false,
        processData: false,
        data:  form_data,
        type: 'post',
        success: function (php_script_response) {
            //document.getElementsByClassName('feed_element')[0].innerHTML = php_script_response;
        }
    });
   

}
function sendComment(e) {
     $id = $(e).attr('data-id');
    $contant = $(e).next().val();
    $.post('comment.php' , {post_id : $id , comment : $contant},function(data){


    });

}

function show_msg(){
    window.location = "msg.php" ;
}


function expand(e) {

    var parent = e.parentElement;
    e.remove();
    parent.innerHTML = parent.innerHTML + "<textarea class='expand' id='comment-1'></textarea>";
    addExpand();
    $('#comment-1').focus();
    $('#comment-1').focusout(function () {
        var parent = this.parentElement;
        if ($('#comment-1').val() == ""){
        this.remove();
        parent.innerHTML = parent.innerHTML + '<input type="text" onclick="expand(this)" placeholder="Comment..">';
        }
    });
}

function statusBar(e) {
    var parent = e.parentElement;
    e.remove();
    parent.innerHTML = parent.innerHTML + "<textarea class='expand' id='expand-status'></textarea>";
    addExpand_status();
    $('#expand-status')[0].focus();

    // alert(height);
    $('#expand-status').focus();
    $('#expand-status').focusout(function () {

        var parent = this.parentElement;
        if ($('#expand-status').val() == "") {
        this.remove();
        parent.innerHTML = parent.innerHTML + '<input type="text" onclick="statusBar(this)" placeholder="What\'s your Plunder?">';
        $(parent).css('height', 'auto');
        var height = $(parent).height();
        $('#status-button').css('top', "" + (height - 13) + "px");
        $('.feed_element').css('top', "" + (height + 48) + "px")
        }

    });
}

function show_comments(e) {
    var flag = $(e).attr("data-flag");

    if (flag == 0) {
        // global e;
        $(e).parent().next().removeClass("disable");
        $(e).attr("data-flag", "1");

    }
    if (flag == 1) {
        //global e;
        $(e).parent().next().addClass("disable");
        $(e).attr("data-flag", "0");

    }

}

function showProfileContant() {
    var x = document.getElementsByClassName("p_details");
    document.getElementById("bio").setAttribute("disabled", "disabled");
    document.getElementById("view").classList.add("selected");
    document.getElementById("edit").classList.remove("selected");
    document.getElementById("change_dp").classList.remove("selected");
    document.getElementById("confirm").classList.add("disable");
    for (i = 0; i < x.length; i++) {
        x[i].setAttribute("disabled", "disabled");
    }

}

document.getElementById("view").addEventListener("click", function () {
    showProfileContant();
    showDetails();

});

document.getElementById("edit").addEventListener("click", function () {
    var x = document.getElementsByClassName("p_details");
    document.getElementById("bio").removeAttribute("disabled");
    this.classList.add("selected");
    document.getElementById("view").classList.remove("selected");
    document.getElementById("change_dp").classList.remove("selected");
    document.getElementById("confirm").classList.remove("disable");
    for (i = 0; i < x.length; i++) {
        x[i].removeAttribute("disabled");
    }

    showDetails();
});

document.getElementById("nav-activity").addEventListener("click", function () {
    document.getElementsByClassName("feed")[0].classList.remove("disable");
    document.getElementsByClassName("profile_Edit")[0].classList.add("disable");
});

document.getElementById("nav-profile").addEventListener("click", function () {
    document.getElementsByClassName("profile_Edit")[0].classList.remove("disable");
    var x = $('#bio');
    var height = x[0].scrollHeight;
    x[0].style.height = "" + (height + 20) + "px";
    x[0].parentElement.style.height = "" + (height + 20) + "px";
    document.getElementsByClassName("feed")[0].classList.add("disable");
});

function updateProfile() {
    $name = $('#profile_name').val();
    $game_tag = $('#profile_game_tag').val();
    $bio = $('#bio').val();
    $phone = $('#profile_phone').val();
    $location1 = $('#profile_location').val();
    $email = $('#profile_email').val();
    $fb = $('#profile_fb').val();
    $gplus = $('#profile_gplus').val();
    $steam = $('#profile_steam').val();
    $.post('update_profile.php', {
            name: $name,
            game_tag: $game_tag,
            bio: $bio,
            phone: $phone,
            location: $location1,
            email: $email,
            fb: $fb,
            gplus: $gplus,
            steam: $steam
        },
        function (data) {
            // document.getElementsByClassName('profile_Edit')[0].innerHTML = data;
            showProfileContant();
        });
}

function showChangePicture() {

    $('.profile_details_form').addClass("disable");
    $('.box-4').removeClass("disable");
}

function showDetails() {
    $('.profile_details_form').removeClass("disable");
    $('.box-4').addClass("disable");

}

var x = document.getElementsByClassName("navbar")[0].offsetHeight;

document.getElementsByClassName("search_bar")[0].style.marginTop = "" + (x * 0.1) + "px";

var url = "feed.php";
var vars = "user_id=" + "1";
