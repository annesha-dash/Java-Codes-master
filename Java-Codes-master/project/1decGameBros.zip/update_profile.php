<?php 
session_start();
include_once('lib.php');
//var_dump($_REQUEST);
$query = 'update profile 
   set  name = "'.$_REQUEST['name'].'",
   game_tag = "'.$_REQUEST['game_tag'].'",
   phone = "'.$_REQUEST['phone'].'",
   bio = "'.$_REQUEST['bio'].'",
   location = "'.$_REQUEST['location'].'"
   where id = "'.$_SESSION['p_id'].'"';
q($query);


$query1 = "select l_id from profile where id=".$_SESSION['p_id'];
$res = mysqli_fetch_assoc(q($query1));

$query1 = "update link 
           set fb_link ='".$_REQUEST['fb'].
           "', gplus_link = '".$_REQUEST['gplus'].
           "', steam = '".$_REQUEST['steam'].
           " 'where id ='".$res['l_id']."'";
echo $query1;
 q($query1);

$data = $_POST['data'];
$fileName = $_POST['name'];
$serverFile = time().$fileName;
$fp = fopen('/uploads/'.$serverFile,'w'); //Prepends timestamp to prevent overwriting
fwrite($fp, $data);
fclose($fp);
$returnData = array( "serverFile" => $serverFile );
echo json_encode($returnData);



?>