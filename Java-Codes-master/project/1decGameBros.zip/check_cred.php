<?php

require_once('lib.php');
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if(isset($_REQUEST['l_email']) && isset($_REQUEST['l_password'])){
    if(!empty($_REQUEST['l_email']) && !empty($_REQUEST['l_password']) ){
        $chk= substr($_REQUEST['l_email'], strlen($_REQUEST['l_email'])-4 );
        $chk2 = strpos($_REQUEST['l_email'], '@');
        $chk3= substr($_REQUEST['l_email'],$chk2+1, strlen($_REQUEST['l_email'])-4 );
        $chk4 = strpos($chk3, '@');
        if($chk === '.com' && $chk2 !== false && $chk4 === false){
          $chk5= substr($_REQUEST['l_email'],0,1 );
            $query = "select id,p_id from user where email ='".$_REQUEST['l_email']."'
                         and password ='".$_REQUEST['l_password']."'";
                        
        if($a = mysqli_fetch_assoc( mysqli_query($con , $query))){
            $_SESSION['u_id'] = $a['id'];    
            $_SESSION['p_id'] = $a['p_id'];    
            echo "0";
            }
        else{
            echo "1";
        }
        }
        else {
            $chk5= substr($_REQUEST['l_email'],0,1 );
            if($chk5 !== '#'){
                echo "1";
            }
            else {
                $query = "select id,p_id from user where p_id = (select id from profile where game_tag = '".$_REQUEST['l_email']."')
                and password ='".$_REQUEST['l_password']."'";
                echo "hey";
                if($a = mysqli_fetch_assoc( mysqli_query($con , $query))){
                   $_SESSION['u_id'] = $a['id'];
                   $_SESSION['p_id'] = $a['p_id'];    
                    echo "0";

                }
            }
        }
    }
}

    if( isset($_REQUEST['s_email']) && isset($_REQUEST['s_pass']) && isset($_REQUEST['s_rpass'])
        && isset($_REQUEST['s_nick']) ){

        if( !empty($_REQUEST['s_email']) && !empty($_REQUEST['s_pass']) && !empty($_REQUEST['s_rpass'])
            && !empty($_REQUEST['s_nick'])){

            $chk= substr($_REQUEST['s_email'], strlen($_REQUEST['s_email'])-4 );
            $chk2 = strpos($_REQUEST['s_email'], '@');
            $chk3= substr($_REQUEST['s_email'],$chk2+1, strlen($_REQUEST['s_email'])-4 );
            $chk4 = strpos($chk3, '@');
            $msg = "";
            $flag = 0;
            if($chk === '.com' && $chk2 !== false && $chk4 === false){}
            else {
                $msg= $msg."Please enter a valid Email";
                echo "2";
            }

            if($_REQUEST['s_pass'] !== $_REQUEST['s_rpass']){
                $msg = $msg."Passwords do not match";
                echo "3";
            }

            $chk5= substr($_REQUEST['s_nick'],0,1 );
            if($chk5 !== '#'){
                echo "4";
                $msg = $msg. "Nickname must start with '#'";
            }

            if($flag === 0) {
                $query = "insert into link(`fb_link`,`gplus_link`,`steam`) values('','','')";
                q($query);
                $query = "select max(id) from link";
                $result = mysqli_fetch_assoc(q($query));
                $query1 = "insert into profile (`game_tag`, `l_id`) values ('".$_REQUEST['s_nick']."','".$result['max(id)']."')";
                q($query1);
                $query = "select max(id) from profile";
                $res =  q( $query);
                $result = mysqli_fetch_assoc($res);
                $query = "insert into user(`email` , `password` , `p_id` , `access`) 
                        values ('".$_REQUEST['s_email']."','".$_REQUEST['s_pass']."' ,'".$result['max(id)']."','1')";
                q($query);
                $msg = $msg."registered successfully";
                echo "5";
            }
           
        }
    }


?>



