<!DOCTYPE html>
<html>

<head>
	<title>Game Bros</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/main.css?version=6">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet">
	<link href="css/font-awesome.css?version=4.7.0" rel="stylesheet" type="text/css">
</head>

<body>
	<div class="container">
		<h2 class="hidden" id="msg"></h2>
		<div class="login_form">
			<div class="left-box">
				<h3>Why Game alone?</h3>
				<h4>Share your game Score with your friends.</h4>
			</div>
			<div class="right-box">
				<ul class="input " id="login_input_form">
					<form action="" method="">
						<h2>Signing Up Now</h2>
						<div class="label">E-mail</div>
						<li style="margin-bottom:20px">

							<input type="text" name="nick" id="l_email" placeholder="Nickname or, Email">
						</li>
						<div class="label">Password</div>
						<li style="margin-bottom:20px">

							<input type="password" name="password" id="l_pass" placeholder="Password">
						</li>
						<li>
							<div id="error-msg"></div>
						</li>
						<li id="forgot">
								<a href="#">Forgot Password</a>
							</li>
						<li style="clear:both">
							<button type="button" id="l_confirm">Login</button>
						</li>
						
						<h3 style="  margin-top: 20px;">Not a member?
							<a href="#" id="signUp"> Sign up</a>
						</h3>
					</form>
				</ul>
				<ul class="input hidden" id="sign_up_form">
					<h2>Signing Up Now</h2>
					<form action="" method="">
							<div class="label">E-mail</div>
						<li>
							<input type="email" data-input-type="1" id="s_email" onkeydown="checkExist(this)" onkeyup="checkExist(this)"  placeholder="Email">
							<i class="fa fa-exclamation-circle disable" title="Must be a valid E-mail i.e abc@example.com" aria-hidden="true" style="font-size:26px;"></i>
						</li>
						<div class="label">Nick</div>
						<li>
							<input type="text" name="nick" data-input-type="2" id="s_nick" onkeydown="checkExist(this)"  onkeyup="checkExist(this)" placeholder="Nickname">
							<i class="fa fa-exclamation-circle disable" aria-hidden="true" title="Must start with '#'" style="font-size:26px;"></i>
						</li>
						<div class="label">Password</div>
						<li>
							<input type="password" name="password" data-input-type="3" id="s_pass" onkeydown="checkExist(this)" onkeyup="checkExist(this)" placeholder="Password">
							<i class="fa fa-exclamation-circle disable" aria-hidden="true" title="Must be atleast 8 charecters and contain 1 uppercase charecter"  style="font-size:26px;"></i>
						</li>
						<div class="label">Re-enter Password</div>
						<li>
							<input type="password" name="rpassword" data-input-type="4"  id="s_rpass" onkeydown="checkExist(this)" onkeyup="checkExist(this)" placeholder="Confirm Password">
							<i class="fa fa-exclamation-circle disable" aria-hidden="true" title="Passwords must match" style="font-size:26px;"></i>
						</li>
						
						<li>
							<div id="error-msg1"></div>
						</li>
						<li>
							<button type="button" id="s_confirm" onclick="return validateReg()" value="Confrim">Confirm</button>
						</li>
						<h3 style="  margin-top: 10px;">Already have an account?
							<a href="#" id="login"> Sign in</a>
						</h3>
					</form>
				</ul>

			</div>
		</div>
</body>
<footer>

</footer>

</html>
<script src="js/login_script.js?version=11"></script>