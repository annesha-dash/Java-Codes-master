<?php
 session_start();
include_once('lib.php');
   if(isset($_REQUEST['post'])){

        $_SESSION['post'] = $_REQUEST['post'];

   }
   else{
          echo "hey2";
       
     if(isset($_FILES['file']['tmp_name'])) {
          echo "hey1";
            $filename = $_FILES['file']['name'];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            if(  $ext !== 'jpg' ) {
            echo "<script> alert('Error Uplaoding file! ONLY JPG FILES ');</script>";
             echo '<script>window.location = "index.php";</script>';
              exit();
          }
            else{
                echo "hey";
                $query1 = 'insert into post (`p_id` , `time` , `post_text`) 
                values("'.$_SESSION['p_id'].'",now(), "'.$_SESSION['post'].'")';
                echo $query1;
                q($query1);
                $query1 = 'select max(id) from post';
                $post_id = mysqli_fetch_assoc(q($query1));
                $pic = 'img/posts/'.$post_id['max(id)'].'/post.jpg';
                $tmp_name=$_FILES['file']['tmp_name'];
                mkdir( 'img/posts/'.$post_id['max(id)'], 0755, true );
                move_uploaded_file($tmp_name,$pic);
                $query1 = 'update post set picture_loc = "'.$pic.'"
                where id = "'.$post_id['max(id)'].'"';
                echo $query1;
                q($query1);

                echo "<script> alert('Profile Picture Uploaded Successfully');</script>";
                echo '<script>window.location = "index.php";</script>';
                exit();
             // unset($_FILES['file']['tmp_name']);
            }
 }
}


            echo '<div class="alert alert-danger"><h3>SESSION</h3>';
            echo var_dump($_SESSION).'</div>';

            echo '<div class="alert alert-danger"><h3>Request</h3><hr>';
            echo var_dump($_REQUEST).'</div>';

            echo '<div class="alert alert-danger"><h3>GET</h3><hr>';
            echo var_dump($_GET).'</div>';

            echo '<div class="alert alert-danger"><h3>POST</h3><hr>';
            echo var_dump($_POST).'</div>';
             echo '<div class="alert alert-danger"><h3>FILE</h3><hr>';
            echo var_dump($_FILES).'</div>';

            echo '<div class="alert alert-danger"><h3>SQL LOG</h3><hr>';
            echo $sql_log.'</div>';
?>