<?php
include_once('lib.php');

if( isset( $_REQUEST['type'] ) ) {
    if($_REQUEST['type'] == 1) 
    {
        forFriends();
        forFollower();
        forFollowing();
    }
    if($_REQUEST['type'] == 2) forFriends();
    if($_REQUEST['type'] == 3) forFollower();
    if($_REQUEST['type'] == 4) forFollowing();
}

function forFriends()
{

$query = "select p_id,f_p_id from added_friends 
            where (p_id = '".$_SESSION['p_id']."' or f_p_id = '".$_SESSION['p_id']."') 
            and type = 1";
 $result = q($query);
while($res = mysqli_fetch_assoc($result)){
    if($res['p_id'] == $_SESSION['p_id'])
    {
       
        $query1 = "select * from post where p_id = '".$res['f_p_id']."'order by id DESC";
        $result1 = q($query1);  
        getPost($result1);
    }
    else{

        $query1 = "select * from post where p_id = '".$res['p_id']."'order by id DESC";
        $result1 = q($query1);
        getPost($result1);

    }

}
}

function forFollowing()
{

$query = "select p_id,f_p_id from added_friends 
            where p_id = '".$_SESSION['p_id']."'
            and type = 2";
$result = q($query);
while($res = mysqli_fetch_assoc($result)){
    if($res['p_id'] == $_SESSION['p_id'])
    {
       
        $query1 = "select * from post where p_id = '".$res['f_p_id']."'order by id DESC";
        $result1 = q($query1);  
        getPost($result1);
    }
    else{

        $query1 = "select * from post where p_id = '".$res['p_id']."'order by id DESC";
        $result1 = q($query1);
        getPost($result1);

    }

}
}

function forFollower()
{

$query = "select p_id,f_p_id from added_friends 
            where f_p_id = '".$_SESSION['p_id']."'
            and type = 3";
$result = q($query);
while($res = mysqli_fetch_assoc($result)){
    if($res['p_id'] == $_SESSION['p_id'])
    {
       
        $query1 = "select * from post where p_id = '".$res['f_p_id']."'order by id DESC";
        $result1 = q($query1);  
        getPost($result1);
    }
    else{

        $query1 = "select * from post where p_id = '".$res['p_id']."'order by id DESC";
        $result1 = q($query1);
        getPost($result1);

    }

}
}



function getPost($result){
    $query2 = "select d_p_loc from profile where id ='".$_SESSION['p_id']."'" ;
    $res2 = mysqli_fetch_assoc(q($query2));
    //print_r( mysqli_fetch_assoc($result));
while ( $x = mysqli_fetch_assoc($result) ) {
    
    $query3 = "select * from comment where p_id = '".$x['id']."'";
    
    $query1 = "select name,d_p_loc from  profile where id =".$x["p_id"];
    $res1 = mysqli_fetch_assoc(q($query1));
   
    echo '<div class="post" >
    <div class="post-user">
        <div class="post-user-img">
            <img src="'.$res1["d_p_loc"].'" alt="">
        </div>
        <div class="post-user-name">
            <a href="">'.$res1["name"].'</a>
            <span>'.$x["time"].'</span>
        </div>
    </div>
    <h2></h2>
    <div class="post-contant">'.$x["post_text"].'</div>
    <div class="post-img">
        <img src="'.$x["picture_loc"].'" alt="">
    </div>
    <div class="post-hash">
        <div class="post-badge">
            #fun
        </div>
    </div>
    <div class="post-activity">
        <button class="show-comment" data-flag="0" onclick="show_comments(this)">
            <i class="fa fa-comment-o" aria-hidden="true" style="margin-right: 5px"></i>Comment</button>
    </div>
    <div class="comment-list disable">';
    $res3 = q($query3);
    while($y = mysqli_fetch_assoc($res3)){
        $query4 = 'select name,d_p_loc from profile where id ="'.$y['u_id'].'"';
        $z = mysqli_fetch_assoc(q($query4));
        echo '<div class="comment" id="post-comment-1">
            <img src="'.$z['d_p_loc'].'" alt="">
            '.$z['name'].'<span>'. $y['time'].'</span>
            <h2>'.$y['comment'].'</h2>
        </div>';
    
    }
    
    
    echo '</div>
    <div class="post-comment">
        <img src="'.$res2["d_p_loc"].'" alt="">
        <input type="text" onclick="expand(this)" placeholder="Comment..">
        <button class="send-comment" onclick="sendComment(this)" data-id = "'.$x['id'].'" >
            <i class="fa fa-paper-plane-o" aria-hidden="true"></i>
        </button>
        </div>
    </div>';
}
}



?>
    <?php

            echo '<div class="alert alert-danger"><h3>SESSION</h3>';
            echo var_dump($_SESSION).'</div>';

            echo '<div class="alert alert-danger"><h3>Request</h3><hr>';
            echo var_dump($_REQUEST).'</div>';

            echo '<div class="alert alert-danger"><h3>GET</h3><hr>';
            echo var_dump($_GET).'</div>';

            echo '<div class="alert alert-danger"><h3>POST</h3><hr>';
            echo var_dump($_POST).'</div>';
             echo '<div class="alert alert-danger"><h3>FILE</h3><hr>';
            echo var_dump($_FILES).'</div>';

            echo '<div class="alert alert-danger"><h3>SQL LOG</h3><hr>';
            echo $sql_log.'</div>';

        ?>
