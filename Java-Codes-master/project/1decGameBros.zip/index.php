<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/home.css?version=6">
  <title>Game Bros</title>
  <link href="css/font-awesome.css?version=4.7.0" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <script src="js/jquery.min.js" charset="utf-8"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
  }
    include_once('lib.php');
    if(!isset($_SESSION['u_id'])){
       echo '<script>window.location = "login.php";</script>';
    }
    $query = "select * from profile where id =".$_SESSION['p_id'];
    $profile = mysqli_fetch_assoc(q($query));
    $query2 = "select email from user where id = ".$_SESSION['u_id'];
    $email = mysqli_fetch_assoc(q($query2));
    $query2 = "select * from link where id = ".$profile['l_id'];
    $link = mysqli_fetch_assoc(q($query2));
    //unset($_SESSION['u_id']);

?>

<body class="home">
  <div></div>
  <div class="container">
    <div class="navbar">
      <a href="#">
        <img src="img/logo.png" alt="logo">
      </a>
      <div class="search_bar">
        <input type="text" value="search..">
        <button type="button" id="search">
          <i class="fa fa-search" aria-hidden="true"></i>
        </button>
      </div>
      <h1>
        <a href="#" onclick="show_profile()">
          <i class="fa fa-user" aria-hidden="true"></i>
        </a>
      </h1>
      <h1>
        <a href="#" onclick="show_notification()">
          <i class="fa fa-bell" aria-hidden="true"></i>
        </a>
      </h1>
      <h1>
        <a href="#" onclick="show_msg()">
          <i class="fa fa-inbox" aria-hidden="true"></i>
        </a>
      </h1>
    </div>
    <div class="wrapper">

      <div class="box-1">
        <div class="profile">
          <img src="<?php echo $profile['d_p_loc']; ?>" alt="">
          <div class="pDetails ">
            <h2>
              <i class="fa fa-user-circle" aria-hidden="true"></i>
              <?php echo $profile['name']; ?>
            </h2>
            <h3>
              <i class="fa fa-gamepad" aria-hidden="true"></i>
              <?php echo $profile['game_tag']; ?>
            </h3>
            <h5>
              <?php echo $profile['bio']; ?>
            </h5>
            <h4>
              <i class="fa fa-facebook-official" aria-hidden="true"></i>
              <i class="fa fa-steam-square" aria-hidden="true"></i>
              <i class="fa fa-google-plus-square" aria-hidden="true"></i>
            </h4>
          </div>

          <h2 class="badge">
            <a href="#">
              <div>FOLLOWING</div>
              <i class="fa fa-caret-down" aria-hidden="true"></i>
            </a>
          </h2>
          <h2 class="badge">
            <a href="#">
              <div>FOLLOWERS</div>
              <i class="fa fa-caret-down" aria-hidden="true"></i>
            </a>
          </h2>
          <h2 class="badge">
            <a href="#">
              <div>FRIENDS</div>
              <i class="fa fa-caret-down" aria-hidden="true"></i>
            </a>
          </h2>
        </div>
      </div>

      <div class="box-2">
        <div class="nav-inside">
          <ul>
            <li class="item-1">
              <button id="nav-activity" onclick="loadAll()">ACTIVITY</button>
            </li>
            <li class="item-2">
              <button id="nav-profile">PROFILE</button>
            </li>
            <li class="item-3">
              <button id="nav-friend" onclick="loadFriend()">FRIENDS</button>
            </li>
            <li class="item-4">
              <button id="nav-following" onclick="loadFollower()">FOLLOWING</button>
            </li>
            <li class="item-5">
              <button id="nav-follower" onclick="loadFollowing()">FOLLOWERS</button>
            </li>
          </ul>
        </div>
        <div class="feed ">
          <div class="status">
            <div id="status-dp">
              <img src="<?php echo $profile['d_p_loc']; ?>" alt="">
            </div>
            <input type="text" onclick="statusBar(this)" placeholder="Whats Your Plunder?">
            <div>
               Upload Picutre
            </div>
            <input type="file" id="post-picture" name="postFile" value="">
            <button id="status-button" onclick="sharePost()">
              <i class="fa fa-paper-plane" aria-hidden="true"></i>
            </button>
          </div>
          <div class="feed_element">

        
        <?php 
          if(isset($_FILES['file']['tmp_name']))
          {
            $filename = $_FILES['file']['name'];
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            if(  $ext !== 'jpg' ) {
            echo "<script> alert('Error Uplaoding file! ONLY JPG FILES ');</script>";
             echo '<script>window.location = "index.php";</script>';
              exit();
          }
            else{
             $tmp_name=$_FILES['file']['tmp_name'];
              move_uploaded_file($tmp_name,'img/users/'.$_SESSION['p_id'].'/profile.jpg');
              echo "<script> alert('Profile Picture Uploaded Successfully');</script>";
              echo '<script>window.location = "index.php";</script>';
              exit();
             // unset($_FILES['file']['tmp_name']);
            }
          }
        ?>
          </div>
        </div>
        <div class="profile_Edit disable">
          <div class="box-3">
            <button class="pp_button selected" id="view">View</button>
            <button class="pp_button" id="edit">Edit</button>
            <button class="pp_button" onclick="showChangePicture()" id="change_dp">Change Picture</button>
            <button class="pp_button disable" id="confirm" onclick="updateProfile()" style="margin-left: 50%;background-color:rgb(93, 189, 93);">Confirm</button>
            
            <div class="profile_details_form">
            <h2>Basic</h2>
            <br>
            <br>
            <div class="p_element">Name
              <input class="p_details" id="profile_name" disabled="disabled" type="text" value="<?php echo $profile['name']; ?>">
            </div>
            <div class="p_element">Game Tag
              <input class="p_details" id="profile_game_tag" type="text" disabled="disabled" value="<?php echo $profile['game_tag']; ?>">
            </div>
            <div class="p_element" style="height : 100px">Bio
              <textarea disabled="disabled" id="bio"><?php echo $profile['bio']; ?></textarea>
            </div>

            <div class="p_element">Phone
              <input class="p_details" id="profile_phone" type="text" disabled="disabled" value="<?php echo $profile['phone']; ?>">
            </div>
            <div class="p_element">location
              <input class="p_details" id="profile_location" type="text" disabled="disabled" value="<?php echo $profile['location']; ?>">
            </div>
            <div class="p_element">Email
              <input class="p_details" id="profile_email" type="text" disabled="disabled" value="<?php echo $email['email']; ?>">
            </div>
            <h2>Socails</h2>
            <br>
            <br>
            <div class="p_element">Facebook
              <input type="text" id="profile_fb" class="p_details" disabled="disabled" value="<?php echo $link['fb_link']; ?>">
            </div>
            <div class="p_element">Steam
              <input type="text" id="profile_steam" class="p_details" disabled="disabled" value="<?php echo $link['steam']; ?>">
            </div>
            <div class="p_element">Google+
              <input type="text" id="profile_gplus" class="p_details" disabled="disabled" value="<?php echo $link['gplus_link']; ?>">
            </div>
                          
            </div>
            <div class="box-4 disable">
            <div class="p_element" id="upload_picture" style="padding:10px">Picture
              <form  method="post" enctype="multipart/form-data">
                <input type="file" name="file" id="upload_picture_box" class="p_details">
                <input type="submit" onclick="showDetails()" value="submit">
              </form><br><br><h2 style="color : red">ONLY JPG FILES ALLOWED</h2> 
            </div>
          </div>
          </div>
        </div>
      </div>

    </div>
</body>
<script src="js/index_function.js?version=7 charset="utf-8"></script>
<?php
// include_once('footer.php');
?>

</html>