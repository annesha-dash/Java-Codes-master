<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
  }
$sql_log = "";

$con = mysqli_connect('localhost','root','','game_bros');

if(mysqli_connect_errno()) $error_log += "connection faild";

mysqli_set_charset($con,'utf8');


function f($ar)
{
	return mysqli_fetch_array($ar);
}

function q($q) {
	//echo '<p class="alert alert-danger">'.$q.'</p>';
	$q = mysql_lower($q);
	global $cur_date;

	global $con;
	global $uid;
	global $sql_log;
	$sql_log .= $q.';<br/>
	';
	$res = mysqli_query($con,$q);
	$uid = mysqli_insert_id($con);
	//echo $q.' => '.$uid.' <br/>';
	return $res;
}


function mysql_lower($s)
{
	$s = str_ireplace("insert","insert",$s);
	$s = str_ireplace("into","into",$s);
	$s = str_ireplace("select","select",$s);
	$s = str_ireplace("update","update",$s);
	$s = str_ireplace("delete","delete",$s);
	$s = str_ireplace("from","from",$s);
	$s = str_ireplace("where","where",$s);
	$s = str_ireplace("values","values",$s);
	$s = str_ireplace("and","and",$s);
	$s = str_ireplace("or","or",$s);
	$s = str_ireplace("join","join",$s);
	$s = str_ireplace("left","left",$s);
	$s = str_ireplace("right","right",$s);
	$s = str_ireplace("on","on",$s);
	$s = str_ireplace("in","in",$s);
	$s = str_ireplace("order by","order by",$s);
	$s = str_ireplace("limit","limit",$s);
	$s = str_ireplace("group by","group by",$s);
	$s = str_ireplace("coalesce","coalesce",$s);
	$s = str_ireplace("date","date",$s);
	$s = str_ireplace("sum","sum",$s);
	$s = str_ireplace("DATE_FORMAT","date_format",$s);
	$s = str_ireplace("DATETIME","datetime",$s);
	return $s;
}

function is($a)
{
	if(isset($_REQUEST[$a]))
		return true;
	else false;
}

function r($a)
{
$a = strtolower($a);
	global $con;
	if(isset($_REQUEST[$a]))
		return mysqli_escape_string($con,$_REQUEST[$a]);
	else return '';
}

function rn($a)
{
	global $con;
	if(isset($_REQUEST[$a]))
		return mysqli_escape_string($con,$_REQUEST[$a]);
	else return 0;
}


function data_in_table($table_name, $id, $required_column)
{
	$q = q('select '.$required_column.' from '.$table_name.' where id = "'.$id.'"');
	//echo $required_column.'..'.$table_name;
	if($r = mysqli_fetch_array($q))
		return $r[$required_column];
    
    }

?>