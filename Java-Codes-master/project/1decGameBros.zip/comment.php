<?php 

    include_once('lib.php');

    $query = 'insert into comment (`u_id` , `time`, `comment` , `p_id`)
             values("'.$_SESSION['p_id'].'",now() , "'.$_REQUEST['comment'].'","'.$_REQUEST['post_id'].'" )';
    q($query);


?>

<?php

            echo '<div class="alert alert-danger"><h3>SESSION</h3>';
            echo var_dump($_SESSION).'</div>';

            echo '<div class="alert alert-danger"><h3>Request</h3><hr>';
            echo var_dump($_REQUEST).'</div>';

            echo '<div class="alert alert-danger"><h3>GET</h3><hr>';
            echo var_dump($_GET).'</div>';

            echo '<div class="alert alert-danger"><h3>POST</h3><hr>';
            echo var_dump($_POST).'</div>';
             echo '<div class="alert alert-danger"><h3>FILE</h3><hr>';
            echo var_dump($_FILES).'</div>';

            echo '<div class="alert alert-danger"><h3>SQL LOG</h3><hr>';
            echo $sql_log.'</div>';

        ?>
